echo > /var/log/xray/access.log
