<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?color=%2336BCF7&center=true&vCenter=true&lines=WINGS+XRAY+MULTIPATH"/>
</p>

### TANPA REGIST IP LANGSUNG GAS INSTALL

# Required
- DOMAIN (HARUS PUNYA)
- DEBIAN 9/10/11
- Ubuntu 18/20/21/22 (rekomendasi Ubuntu 20.04) 
- CPU MINIMAL 1 CORE
- RAM 1GB
- GANTI KE XRAY MOD UNTUK SUPOT MULTIPATH NYA➡️CERT DOMAIN➡️ CTRL C REBOOT ✅

</p> 
<h2 align="center"> Supported Linux Distribution</h2>
<p align="center"><img src="https://d33wubrfki0l68.cloudfront.net/5911c43be3b1da526ed609e9c55783d9d0f6b066/9858b/assets/img/debian-ubuntu-hover.png"></p> 
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%209&message=Stretch&color=purple"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=purple">  <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2018&message=Lts&color=red"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2020&message=Lts&color=red">
</p>
</div>
UPDATE DULU SEBELUM INSTALL..!! 

# UPDATE UNTUK DEBIAN
apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot
# UPDATE UNTUK UBUNTU
apt update && apt upgrade -y && update-grub && sleep 2 && reboot

# Installation
- via WGET
```
wget -q https://raw.githubusercontent.com/wingshope/autoscript/main/xray && chmod +x xray && ./xray
```

### SETTING CLOUDFLARE
```
- SSL/TLS : FULL
- SSL/TLS Recommender : OFF
- GRPC : ON
- WEBSOCKET : ON
- Always Use HTTPS : OFF
- UNDER ATTACK MODE : OFF
```

![FB_IMG_1698279471105](https://github.com/wingshope/autoscript/assets/138878860/97534ba6-b12b-448a-90e1-b19ba0426765)

